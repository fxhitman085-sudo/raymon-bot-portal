const path = require('node:path');
require('dotenv').config();

const digits = (value) => String(value || '').replace(/\D/g, '');

module.exports = Object.freeze({
  name: 'RAYMON BOT',
  prefix: '.',
  channelUrl: process.env.WHATSAPP_CHANNEL_URL ?? 'https://whatsapp.com/channel/0029VbAgWFtJf05e9WdnO71D',
  ownerNumber: digits(process.env.OWNER_NUMBER),
  pairingNumber: digits(process.env.PAIRING_NUMBER),
  geminiApiKey: process.env.GEMINI_API_KEY || '',
  geminiModel: process.env.GEMINI_MODEL || 'gemini-2.5-flash',
  tmdbApiKey: process.env.TMDB_API_KEY || '',
  giphyApiKey: process.env.GIPHY_API_KEY || '',
  geniusToken: process.env.GENIUS_ACCESS_TOKEN || '',
  auddToken: process.env.AUDD_API_TOKEN || '',
  dataDir: path.resolve(process.env.DATA_DIR || './data'),
  authDir: path.resolve(process.env.AUTH_DIR || './data/auth'),
  tempDir: path.resolve(process.env.TEMP_DIR || './tmp'),
  logLevel: process.env.LOG_LEVEL || 'info',
  maxMediaBytes: 50 * 1024 * 1024,
  statusEmojis: ['❤️', '🔥', '😂', '😍', '🥰', '💯', '🙌', '😎', '💙']
});
