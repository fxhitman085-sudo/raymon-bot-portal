const {DEFAULT_MESSAGE}=require('../lib/away');
const cmd=(name,description,usage,execute)=>({name,description,usage,category:'Away replies',ownerOnly:true,execute});
const status=state=>`Away replies: ${state.enabled?'enabled':'disabled'}\nAway now: ${state.active?'yes — use .back to return':'no'}\nAutomatic after 15 minutes: ${state.automatic?'on':'off'}\nMessage: ${state.message}`;
module.exports=[
 cmd('away','Activate your account’s private-chat away replies','.away',async(ctx,args)=>args.length?{ok:false,message:'Usage: .away'}:{ok:true,message:`Away replies are active for every new personal DM. Use .back to stop them.\n\n${ctx.away.setAway().message}`}),
 cmd('back','Stop away replies and restart your inactivity timer','.back',async(ctx,args)=>{
  if(args.length)return {ok:false,message:'Usage: .back'};const s=ctx.away.back();return {ok:true,message:`Welcome back. Away replies stopped.${s.enabled&&s.automatic?' They will activate again after 15 minutes without a manual message.':''}`};
 }),
 cmd('offlinereply','Enable, disable, preview or configure automatic away activation','.offlinereply [on|off|test|auto on|auto off]',async(ctx,args)=>{
  const [action,value]=args.map(x=>x.toLowerCase());
  if(!args.length)return {ok:true,message:status(ctx.away.reconcile())};
  if(args.length===1&&['on','off'].includes(action))return {ok:true,message:status(ctx.away.enable(action==='on'))};
  if(args.length===1&&action==='test')return {ok:true,message:ctx.away.state().message};
  if(args.length===2&&action==='auto'&&['on','off'].includes(value))return {ok:true,message:status(ctx.away.automatic(value==='on'))};
  return {ok:false,message:'Usage: .offlinereply on|off|test|auto on|auto off'};
 }),
 cmd('config','Show or customize your account’s away message','.config offlinemsg [your message|reset]',async(ctx,args)=>{
  if(args[0]?.toLowerCase()!=='offlinemsg')return {ok:false,message:'Usage: .config offlinemsg [your message|reset]'};
  if(args.length===1)return {ok:true,message:`${status(ctx.away.reconcile())}\n\nChange it: .config offlinemsg Your message here\nReset it: .config offlinemsg reset`};
  try{const s=ctx.away.setMessage(args.length===2&&args[1].toLowerCase()==='reset'?DEFAULT_MESSAGE:args.slice(1).join(' '));return {ok:true,message:`Away message saved:\n${s.message}`};}catch(error){return {ok:false,message:error.message};}
 })
];
