const {sendList}=require('../lib/presentation');
const cmd = (name, description, usage, execute, extra={}) => ({ name, description, usage, category:'General', execute, ...extra });

module.exports = [
  cmd('menu','Show the categorized command menu','.menu', async ctx => {const {helpText}=require('../lib/commands');const caption=`╭──〔 ⚡ *RAYMON BOT* 〕\n│ RAYMON BOT — COMMAND MENU\n│ Mode: ${ctx.db.get('mode','private').toUpperCase()}\n│ Prefix: .  •  Uptime: ${formatDuration(process.uptime())}\n╰──────────────\n\n${helpText()}\n\n🔐 Owner • 🛡️ Group admin\nUse .help command for details.\nAI: .ai your question`; if(!ctx.sock?.sendMessage)return {ok:true,message:caption}; return sendList(ctx,caption);}),
  cmd('help','Show command usage and permission notes','.help [category]', async (ctx,args) => {const {helpText}=require('../lib/commands');return { ok:true, message:`📘 *RAYMON BOT HELP*\n${helpText(args.join(' '),ctx) || 'No commands found in that category.'}` };}),
  cmd('ping','Check bot responsiveness','.ping', async () => ({ ok:true, message:'🏓 Pong! RAYMON BOT is responding.' })),
  cmd('uptime','Show bot uptime','.uptime', async ctx => ({ ok:true, message:`⏱️ Uptime: ${formatDuration(process.uptime())}\nMemory: ${Math.round(process.memoryUsage().rss/1024/1024)} MB RSS` })),
  cmd('botinfo','Show bot name, mode and runtime info','.botinfo', async ctx => ({ ok:true, message:`🤖 *${ctx.config.name}*\nWhatsApp connection: ${ctx.connected?'online':'starting'}\nMode: ${ctx.db.get('mode','private').toUpperCase()}\nGemini: ${ctx.ai?.available?'configured':'not configured'}\nNode.js: ${process.version}\nCommands: ${ctx.commandCount}` })),
  cmd('groups','List groups this account has loaded','.groups', async ctx => {
    const groups=await ctx.sock.groupFetchAllParticipating(); const list=Object.values(groups);
    if(!list.length) return {ok:true,message:'I do not see any groups on this linked account yet.'};
    return {ok:true,message:`👥 *Groups (${list.length})*\n${list.slice(0,50).map((g,i)=>`${i+1}. ${g.subject || g.id}`).join('\n')}${list.length>50?'\n…and more':''}`};
  }, {ownerOnly:true}),
  cmd('groupinfo','Show basic information about this group','.groupinfo', async ctx => {
    const md=await ctx.sock.groupMetadata(ctx.jid); return {ok:true,message:`👥 *${md.subject}*\nMembers: ${md.participants.length}\nCreated: ${md.creation?new Date(md.creation*1000).toLocaleDateString():'unknown'}\nDescription: ${md.desc||'none'}`};
  }, {groupOnly:true})
];

function formatDuration(seconds) { const s=Math.floor(seconds), d=Math.floor(s/86400), h=Math.floor(s%86400/3600), m=Math.floor(s%3600/60); return [d&&`${d}d`,h&&`${h}h`,m&&`${m}m`,`${s%60}s`].filter(Boolean).join(' '); }
