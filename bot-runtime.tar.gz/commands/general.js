const {sendList}=require('../lib/presentation');
const {validPrefix,getPrefix,setPrefix}=require('../lib/prefix');
const cmd = (name, description, usage, execute, extra={}) => ({ name, description, usage, category:'General', execute, ...extra });

module.exports = [
  cmd('menu','Show the categorized command menu','.menu', async ctx => {
    const {helpText}=require('../lib/commands');
    const prefix=ctx.prefix||ctx.config?.prefix||'.';
    const caption=[
      '*RAYMON BOT — COMMAND MENU*',
      helpText('',{...ctx,prefix}),
      `Use ${prefix}help <command> for details.`
    ].join('\n\n');
    if(!ctx.sock?.sendMessage)return {ok:true,message:caption};
    return sendList(ctx,caption);
  }),
  cmd('help','Show command usage and permission notes','.help [command or category]', async (ctx,args) => {
    const {helpText}=require('../lib/commands');
    return {ok:true,message:`*RAYMON BOT HELP*\n\n${helpText(args.join(' '),ctx)||'No commands found in that category.'}`};
  }),
  cmd('prefix','Show or change your personal command prefix','.prefix [new prefix]',async(ctx,args)=>{
    const prefix=getPrefix(ctx.db,ctx.config,ctx.sender,ctx.senderNumber);
    if(!args.length)return {ok:true,message:`Your current prefix is “${prefix}”. To change it, use ${prefix}prefix !`};
    if(args.length!==1||!validPrefix(args[0]))return {ok:false,message:`Use ${prefix}prefix followed by 1–3 punctuation characters, such as ! or ?.`};
    if(!setPrefix(ctx.db,ctx.sender,ctx.senderNumber,args[0]))return {ok:false,message:'I could not identify your WhatsApp account. Try again in a direct chat.'};
    return {ok:true,message:`Your prefix is now “${args[0]}”. Try ${args[0]}menu. To restore the default, use ${args[0]}prefix .`};
  },{allowPrivate:true,prefixOnly:true}),
  cmd('ping','Check bot responsiveness','.ping', async () => ({ ok:true, message:'🏓 Pong! RAYMON BOT is responding.' })),
  cmd('uptime','Show bot uptime','.uptime', async ctx => ({ ok:true, message:`⏱️ Uptime: ${formatDuration(process.uptime())}\nMemory: ${Math.round(process.memoryUsage().rss/1024/1024)} MB RSS` })),
  cmd('botinfo','Show bot name, mode and runtime info','.botinfo', async ctx => ({ ok:true, message:`🤖 *${ctx.config.name}*\nWhatsApp connection: ${ctx.connected?'online':'starting'}\nMode: ${ctx.db.get('mode','private').toUpperCase()}\nGemini: ${ctx.ai?.available?'configured':'not configured'}\nNode.js: ${process.version}\nCommands: ${ctx.commandCount}` })),
  cmd('groups','List groups this account has loaded','.groups', async ctx => {
    const groups=await ctx.sock.groupFetchAllParticipating(); const list=Object.values(groups);
    if(!list.length) return {ok:true,message:'I do not see any groups on this linked account yet.'};
    return {ok:true,message:`👥 *Groups (${list.length})*\n${list.slice(0,50).map((g,i)=>`${i+1}. ${g.subject || g.id}`).join('\n')}${list.length>50?'\n…and more':''}`};
  }, {ownerOnly:true}),
  cmd('groupinfo','Show basic information about this group','.groupinfo', async ctx => {
    const md=await ctx.sock.groupMetadata(ctx.jid); return {ok:true,message:`👥 *${md.subject}*\nMembers: ${md.participants.length}\nCreated: ${md.creation?new Date(md.creation*1000).toLocaleDateString():'unknown'}\nDescription: ${md.desc||'none'}`};
  }, {groupOnly:true})
];

function formatDuration(seconds) { const s=Math.floor(seconds), d=Math.floor(s/86400), h=Math.floor(s%86400/3600), m=Math.floor(s%3600/60); return [d&&`${d}d`,h&&`${h}h`,m&&`${m}m`,`${s%60}s`].filter(Boolean).join(' '); }
