const {jidNormalizedUser}=require('@whiskeysockets/baileys');
const {sendList}=require('../lib/presentation');
const PAGE_SIZE=100,COOLDOWN_MS=60000;
const active=new WeakMap();
function identities(values){return [...new Set(values.filter(value=>typeof value==='string').map(jidNormalizedUser).filter(jid=>/^\d+@(s\.whatsapp\.net|lid)$/.test(jid)))];}
function members(participants){
 if(!Array.isArray(participants)||!participants.length||participants.length>5000)throw Error('INVALID_MEMBER_LIST');
 const records=[];
 for(const item of participants){
  const aliases=identities(typeof item==='string'?[item]:[item?.id,item?.lid,item?.phoneNumber,item?.jid]);
  if(!aliases.length)throw Error('INVALID_MEMBER_IDENTITY');
  const matches=records.filter(row=>row.aliases.some(id=>aliases.includes(id)));
  const combined=identities([...matches.flatMap(row=>row.aliases),...aliases]);
  const record=matches[0]||{aliases:[]};record.aliases=combined;
  record.jid=record.jid||aliases[0];
  for(const other of matches.slice(1))records.splice(records.indexOf(other),1);
  if(!matches.length)records.push(record);
 }
 return records;
}
function access(ctx){return ctx.db.get('tagall.access','everyone')==='everyone'?'everyone':'admins';}
async function tagall(ctx,args=[]){
 if(!ctx.isGroup)return {ok:false,message:'Use .tagall inside a group chat.'};
 if(args.length)return {ok:false,message:'Usage: .tagall'};
 if(access(ctx)==='admins'&&!await ctx.isGroupAdmin(ctx.sender,ctx.jid))return {ok:false,message:'This bot account’s owner has restricted .tagall to group admins.'};
 let running=active.get(ctx.db);if(!running){running=new Set();active.set(ctx.db,running);}
 if(running.has(ctx.jid))return {ok:false,message:'A group mention is already being sent here.'};
 const cooldownKey=`tagall.last:${ctx.jid}`,last=ctx.db.get(cooldownKey,0),remaining=last+COOLDOWN_MS-Date.now();
 if(last&&remaining>0)return {ok:false,message:`Please wait ${Math.ceil(remaining/1000)} seconds before using .tagall again in this group.`};
 running.add(ctx.jid);let sending=false;
 try{
  let metadata;
  try{metadata=await ctx.sock.groupMetadata(ctx.jid);}catch{return {ok:false,message:'I could not load this group’s current members. Check that this bot account is still in the group, then try again.'};}
  let roster;
  try{roster=members(metadata?.participants);}catch{return {ok:false,message:'WhatsApp did not provide a complete usable member list. No group mention was sent.'};}
  const sender=identities([ctx.sender,ctx.senderNumber?`${ctx.senderNumber}@s.whatsapp.net`:null,ctx.message?.key?.participantAlt]);
  if(!roster.some(row=>row.aliases.some(id=>sender.includes(id))))return {ok:false,message:'You must be a current member of this group to use .tagall.'};
  const shared=ctx.sessions?.db||ctx.db,id=ctx.message?.key?.id;
  if(id&&shared.claimMessage&&!shared.claimMessage(`tagall:${ctx.jid}:${id}`))return {ok:true,sent:true};
  const subject=String(metadata.subject||'This group').replace(/[\r\n*\u0000-\u001f]/g,' ').replace(/\s+/g,' ').trim().slice(0,100);
  const pages=Math.ceil(roster.length/PAGE_SIZE),width=Math.max(2,String(roster.length).length);
  // Persist before the first external send; ambiguous or partial failures are never automatically replayed.
  ctx.db.set(cooldownKey,Date.now());sending=true;
  for(let start=0;start<roster.length;start+=PAGE_SIZE){
   if(ctx.isActive?.()===false)throw Error('TAGALL_CONNECTION_CHANGED');
   if(ctx.db.get('mode','private')==='private'&&ctx.senderNumber!==ctx.config.ownerNumber)throw Error('TAGALL_MODE_CHANGED');
   if(access(ctx)==='admins'&&!await ctx.isGroupAdmin(ctx.sender,ctx.jid))throw Error('TAGALL_ACCESS_CHANGED');
   const page=roster.slice(start,start+PAGE_SIZE);
   const text=`📣 *RAYMON BOT — TAG ALL*\n\n*Group:* ${subject}\n*Members:* ${roster.length}${pages>1?`\n*Page:* ${start/PAGE_SIZE+1}/${pages}`:''}\n\n${page.map((row,index)=>`*${String(start+index+1).padStart(width,'0')}.* @${row.jid.split('@')[0]}`).join('\n')}\n\n──────────────\n*Group roll call*`;
   await sendList(ctx,text,{mentions:page.map(row=>row.jid)});
  }
  return {ok:true,sent:true};
 }catch{
  ctx.logger?.warn?.('Group mention processing stopped. Recipient and message details were suppressed.');
  return {ok:false,message:sending?'I could not complete the group mention. Some pages may already have been submitted; I will not resend them automatically.':'The group mention could not be prepared. Please try again.'};
 }finally{running.delete(ctx.jid);}
}
async function configure(ctx,args=[]){
 if(!ctx.config.ownerNumber||ctx.senderNumber!==ctx.config.ownerNumber)return {ok:false,message:'Only this bot account’s verified owner can change tag-all access.'};
 if(args.length>1||args.length&&!['everyone','admins'].includes(args[0].toLowerCase()))return {ok:false,message:'Usage: .tagallaccess everyone | .tagallaccess admins | .tagallaccess'};
 if(args.length)ctx.db.set('tagall.access',args[0].toLowerCase());
 return {ok:true,message:`Tag-all access for this bot account: *${access(ctx)}*.\n${args.length?'Saved across restarts.':'Everyone is the default.'}\nOnly this account’s verified owner can change it. Public/private mode still applies.`};
}
module.exports=[
 {name:'tagall',description:'Mention and list all current group members; everyone by default, owner-configurable',usage:'.tagall',category:'Group utilities',groupOnly:true,execute:tagall},
 {name:'tagallaccess',description:'Owner: choose everyone or group admins for tag-all access on your account',usage:'.tagallaccess [everyone|admins]',category:'Owner controls',ownerOnly:true,execute:configure}
];
module.exports.members=members;
module.exports.PAGE_SIZE=PAGE_SIZE;
module.exports.COOLDOWN_MS=COOLDOWN_MS;
