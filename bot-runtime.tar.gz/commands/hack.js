const {isOwnerNumber}=require('../lib/ownership');
// Scripted entertainment only: this module performs no scanning or account access.
const {setTimeout: delay}=require('node:timers/promises');
const LINES=Object.freeze([
  "Hacking sequence initiated.",
  "Initializing execution environment...",
  "Loading network modules...",
  "Establishing connection...",
  "Connection established.",
  "Resolving target gateway...",
  "Gateway response received.",
  "Analysing network topology...",
  "Mapping active endpoints...",
  "Endpoint mapping complete.",
  "Beginning service discovery...",
  "Active service identified.",
  "Collecting protocol signatures...",
  "Protocol signature matched.",
  "Inspecting security configuration...",
  "Perimeter protection detected.",
  "Analysing firewall response...",
  "Filtering rules identified.",
  "Calculating alternate connection path...",
  "Alternate route established.",
  "Opening secure transport channel...",
  "Transport handshake accepted.",
  "Enumerating authentication layers...",
  "Authentication barrier located.",
  "Analysing challenge structure...",
  "Challenge parameters extracted.",
  "Processing access sequence...",
  "Access request rejected.",
  "Reconfiguring session parameters...",
  "Retrying authentication sequence...",
  "Response timing anomaly detected.",
  "Analysing session behaviour...",
  "Session boundary identified.",
  "Synchronizing connection state...",
  "Session synchronization complete.",
  "Revalidating access token...",
  "Access token accepted.",
  "Initial access established.",
  "Checking execution privileges...",
  "Restricted environment detected.",
  "Mapping permission hierarchy...",
  "Privilege boundary located.",
  "Processing elevation sequence...",
  "Awaiting authorization response...",
  "Elevated access confirmed.",
  "Opening protected resource index...",
  "Resource index loaded.",
  "Locating encrypted container...",
  "Encrypted container identified.",
  "Analysing encryption headers...",
  "Header analysis complete.",
  "Initializing decoding pipeline...",
  "Processing data blocks: 12%.",
  "Processing data blocks: 28%.",
  "Processing data blocks: 46%.",
  "Processing data blocks: 63%.",
  "Processing data blocks: 81%.",
  "Processing data blocks: 100%.",
  "Container processing complete.",
  "Preparing secondary analysis stage...",
  "Loading session diagnostics...",
  "Checking route consistency...",
  "Route consistency verified.",
  "Inspecting transport buffers...",
  "Transport buffers synchronized.",
  "Building execution timeline...",
  "Execution timeline assembled.",
  "Reviewing endpoint responses...",
  "Endpoint responses catalogued.",
  "Validating protocol sequence...",
  "Protocol sequence verified.",
  "Inspecting resource manifest...",
  "Resource manifest indexed.",
  "Comparing container signatures...",
  "Container signatures aligned.",
  "Tracing connection checkpoints...",
  "Connection checkpoints resolved.",
  "Checking channel permissions...",
  "Channel permission check complete.",
  "Preparing result structure...",
  "Result structure initialized.",
  "Consolidating analysis records...",
  "Analysis records consolidated.",
  "Checking output consistency...",
  "Output consistency confirmed.",
  "Preparing completion summary...",
  "Completion summary assembled.",
  "Verifying final checkpoint...",
  "Final checkpoint verified.",
  "Verifying output integrity...",
  "Integrity verification passed.",
  "Checking connection stability...",
  "Connection stable.",
  "Finalizing execution sequence...",
  "Generating operation report...",
  "Releasing temporary resources...",
  "Closing active channels...",
  "Remote session terminated.",
  "Operation completed successfully.",
  "ACCESS CONFIRMED. SEQUENCE COMPLETE."
]);
const INTERVAL_MS=250;
const COOLDOWN_MS=300000;

class HackSequence {
  constructor({wait=delay,now=Date.now,interval=INTERVAL_MS}={}){
    this.wait=wait;this.now=now;this.interval=interval;this.active=new Map();
  }
  async execute(ctx,args=[]){
    const action=String(args[0]||'').toLowerCase();
    if(args.length>1||!['','stop'].includes(action))return {ok:false,message:'Usage: .hack | .hack stop'};
    const current=this.active.get(ctx.jid);
    if(action==='stop'){
      if(!current)return {ok:true,message:'No active sequence in this chat.'};
      const owner=isOwnerNumber(ctx.config,ctx.senderNumber);
      if(ctx.sender!==current.sender&&!owner&&!(ctx.isGroup&&await ctx.isGroupAdmin(ctx.sender,ctx.jid)))return {ok:false,message:'Only the starter, bot owner, or a group admin can stop this sequence.'};
      current.controller.abort();
      await current.done;
      return {ok:true,message:'Sequence stopped.'};
    }
    if(this.active.has(ctx.jid))return {ok:false,message:'A sequence is already running here. Use .hack stop.'};
    if(this.active.size>=2)return {ok:false,message:'Two sequences are already running. Try again later.'};
    const keys=[`hack:chat:${ctx.jid}`,`hack:user:${ctx.sender}`];
    const remaining=Math.max(...keys.map(k=>Number(ctx.db.get(k,0))-this.now()));
    if(remaining>0)return {ok:false,message:`Please wait ${Math.ceil(remaining/1000)} seconds before starting another sequence.`};
    const state={sender:ctx.sender,controller:new AbortController()};
    this.active.set(ctx.jid,state);
    for(const key of keys)ctx.db.set(key,this.now()+COOLDOWN_MS);
    // Keep the receive loop free so .hack stop and other commands work immediately.
    state.done=this.run(ctx,state).finally(()=>{if(this.active.get(ctx.jid)===state)this.active.delete(ctx.jid);});
    return {ok:true,sent:true};
  }
  async run(ctx,state){
    try{
      for(let i=0;i<LINES.length;i++){
        if(i)await this.wait(this.interval,undefined,{signal:state.controller.signal});
        if(state.controller.signal.aborted||ctx.isActive?.()===false||ctx.db.get('mode','private')==='private'&&!isOwnerNumber(ctx.config,ctx.senderNumber))return;
        await ctx.sock.sendMessage(ctx.jid,{text:LINES[i]});
      }
    }catch(error){
      if(!state.controller.signal.aborted)ctx.logger?.warn?.('Hack entertainment sequence stopped after a delivery failure.');
    }
  }
  cancelAll(){for(const state of this.active.values())state.controller.abort();}
}
const engines=new WeakMap();
function engine(db){if(!engines.has(db))engines.set(db,new HackSequence());return engines.get(db);}
module.exports=[{name:'hack',description:'Run a fictional 100-message hacker prank; any member may start in public mode; stop with .hack stop',usage:'.hack | .hack stop',category:'Games & fun',execute:(ctx,args)=>engine(ctx.db).execute(ctx,args)}];
module.exports.HackSequence=HackSequence;
module.exports.LINES=LINES;
module.exports.cancelFor=db=>engines.get(db)?.cancelAll();
