const fs=require('node:fs');
const {downloadVerifiedMedia,safeMediaCode}=require('../lib/media-download');
const path=require('node:path');
const os=require('node:os');
const {spawn}=require('node:child_process');
const sharp=require('sharp');
const {jidNormalizedUser,downloadContentFromMessage}=require('@whiskeysockets/baileys');
const cmd=(name,description,usage,execute,extra={})=>({name,description,usage,category:'Media tools',...extra,execute});

async function streamToBuffer(stream,limit){const chunks=[];let length=0;for await(const chunk of stream){length+=chunk.length;if(length>limit)throw new Error('Media exceeds the configured 50 MB limit.');chunks.push(chunk);}return Buffer.concat(chunks);}
function unwrap(m){if(!m)return null;if(m.viewOnceMessage||m.viewOnceMessageV2||m.viewOnceMessageV2Extension)throw new Error('View-once media cannot be exported.');if(m.ephemeralMessage)return unwrap(m.ephemeralMessage.message);if(m.imageMessage?.viewOnce||m.videoMessage?.viewOnce)throw new Error('View-once media cannot be exported.');return m;}
function quotedMedia(ctx){const m=unwrap(ctx.quoted?.message||ctx.quotedMessage);if(!m)return null;for(const [type,key] of [['image','imageMessage'],['video','videoMessage'],['sticker','stickerMessage'],['audio','audioMessage']])if(m[key])return {type,message:m[key]};return null;}
async function getBuffer(media,limit){return downloadVerifiedMedia(media,limit);}
function ffmpeg(args,timeout=0){
  return new Promise((resolve,reject)=>{
    const process=spawn('ffmpeg',args,{stdio:['ignore','ignore','pipe'],timeout,killSignal:'SIGKILL'});
    let stderr='';
    process.stderr.on('data',chunk=>{stderr=(stderr+chunk.toString()).slice(-500);});
    process.on('error',error=>{
      if(error.code==='ENOENT')reject(Object.assign(new Error('FFmpeg is not installed on this host.'),{code:'FFMPEG_MISSING'}));
      else reject(error);
    });
    process.on('close',code=>code===0?resolve():reject(new Error(`FFmpeg failed: ${stderr}`)));
  });
}
async function temp(ctx,ext){fs.mkdirSync(ctx.config.tempDir,{recursive:true,mode:0o700});return path.join(ctx.config.tempDir,`raymon-${process.pid}-${Date.now()}-${Math.random().toString(16).slice(2)}.${ext}`);}
async function imageToSticker(buffer){return sharp(buffer,{limitInputPixels:40_000_000}).resize(512,512,{fit:'inside',withoutEnlargement:true}).webp({quality:82}).toBuffer();}
async function stickerToImage(buffer){return sharp(buffer).png().toBuffer();}

async function identifySong(token,bytes,mimetype){
  const form=new FormData();
  form.append('api_token',token);
  form.append('file',new Blob([bytes],{type:mimetype}),mimetype==='audio/mpeg'?'audio.mp3':'audio');
  const response=await fetch('https://api.audd.io/',{method:'POST',body:form,signal:AbortSignal.timeout(20_000)});
  if(!response.ok)throw new Error('AudD request failed');
  const data=await response.json();
  if(data.status==='error')throw new Error('AudD recognition failed');
  const song=data.result;
  if(!song?.title||!song.artist)return {ok:true,message:'I could not identify a song in that clip.'};
  return {ok:true,message:`🎵 *${song.title}* — ${song.artist}${song.album?`\nAlbum: ${song.album}`:''}${song.song_link?`\n${song.song_link}`:''}`};
}

function availableMedia(m,viewOnceOnly=false){
  let viewOnce=false;
  for(let depth=0;m&&depth<8;depth++){
    const wrapped=m.viewOnceMessage?.message||m.viewOnceMessageV2?.message||m.viewOnceMessageV2Extension?.message;
    viewOnce||=!!wrapped;
    const inner=wrapped||m.ephemeralMessage?.message;
    if(inner){m=inner;continue;}
    const type=m.imageMessage?'image':m.videoMessage?'video':m.audioMessage&&(viewOnce||m.audioMessage.ptt||m.audioMessage.viewOnce)?'audio':null;
    if(!type)return null;
    const message=m[type+'Message'];
    if(!viewOnceOnly||viewOnce||message.viewOnce)return {type,message};
    return null;
  }
  return null;
}
function availableQuotedMedia(ctx){
  return availableMedia(ctx.quoted?.message||ctx.quotedMessage);
}
async function forwardAvailableMedia(ctx,args=[],download=getBuffer){
  const target=ctx.sender?jidNormalizedUser(ctx.sender):'';
  if(!target||!/@(s\.whatsapp\.net|lid)$/.test(target))return {ok:false,message:'I could not identify your private WhatsApp chat.'};
  if(!ctx.db.get('feature.vv',true))return {ok:false,message:'.vv is disabled. Use .enable .vv to turn it on.'};
  const latest=args.length===1&&args[0].toLowerCase()==='dm';
  if(args.length&&!latest)return {ok:false,message:'Reply to media with .vv, or use .vv dm in Message Yourself.'};
  if(latest&&(!ctx.isOwner||!ctx.message?.key?.fromMe||
    ![ctx.botJid,ctx.botLid].filter(Boolean).map(jidNormalizedUser).includes(jidNormalizedUser(ctx.jid||''))))
    return {ok:false,message:'Use .vv dm in your WhatsApp Message Yourself chat.'};
  const media=latest?ctx.recentOwnViewOnce?.():availableQuotedMedia(ctx);
  if(latest&&!media)return {ok:false,message:'No view-once media you sent in a private chat is available from the last five minutes.'};
  if(!media||!media.message.mediaKey||(!media.message.directPath&&!media.message.url))return {ok:false,message:'Reply to an available photo, video or voice note with .vv. WhatsApp has not supplied downloadable media here; expired or unavailable media cannot be recovered.'};
  let data;
  try{data=await download(media,ctx.config.maxMediaBytes);}catch(error){
    const code=safeMediaCode(error);
    ctx.logger?.warn?.({phase:'download',mediaType:media.type,code},'Requested media download failed');
    return {ok:false,message:`Media download failed (${code}). This is a download/decryption failure, not proof that the media expired.`};
  }
  if(!ctx.db.get('feature.vv',true))return {ok:false,message:'.vv was disabled; delivery cancelled.'};
  try{
    const payload=media.type==='audio'
      ?{audio:data,ptt:true,mimetype:media.message.mimetype||'audio/ogg; codecs=opus'}
      :{[media.type]:data,caption:'⚡ RAYMON BOT • Requested media'};
    await ctx.sock.sendMessage(target,payload);
    return {ok:true,sent:true};
  }catch{
    ctx.logger?.warn?.({phase:'send',mediaType:media.type},'Requested media send failed');
    return {ok:false,message:'The media downloaded, but WhatsApp could not send it to your DM. This is a delivery/session failure, not an expired-media error.'};
  }
}

module.exports=[
  ...require('./creative')({quotedMedia,getBuffer,ffmpeg,temp,identifySong}),
  cmd('vv','Send available quoted media to your own DM or retrieve your latest sent view-once media','.vv (reply to media) | .vv dm (Message Yourself)',(ctx,args)=>forwardAvailableMedia(ctx,args)),
  cmd('sticker','Convert a replied image or short video into a WhatsApp sticker','.sticker (reply to image/video)',async(ctx)=>{
    const media=quotedMedia(ctx);if(!media||!['image','video'].includes(media.type))return {ok:false,message:'Reply to an image or video with .sticker. Animated stickers need FFmpeg installed on the host.'};
    const input=await getBuffer(media,ctx.config.maxMediaBytes);const out=await temp(ctx,'webp');
    try{
      if(media.type==='image')fs.writeFileSync(out,await imageToSticker(input),{mode:0o600});
      else {const src=await temp(ctx,'mp4');fs.writeFileSync(src,input,{mode:0o600});try{await ffmpeg(['-y','-i',src,'-t','6','-vf','fps=15,scale=512:512:force_original_aspect_ratio=decrease:flags=lanczos,pad=512:512:(ow-iw)/2:(oh-ih)/2:color=0x00000000','-an','-loop','0','-c:v','libwebp','-q:v','65','-preset','default','-vsync','0',out]);}finally{fs.rmSync(src,{force:true});}}
      await ctx.sock.sendMessage(ctx.jid,{sticker:{url:out},...(ctx.isGroup?{mentions:[]}: {})},{quoted:ctx.message});return {ok:true,sent:true};
    }finally{fs.rmSync(out,{force:true});}
  }),
  cmd('toimage','Convert a replied sticker to PNG','.toimage (reply to sticker)',async ctx=>{const media=quotedMedia(ctx);if(media?.type!=='sticker')return {ok:false,message:'Reply to a sticker with .toimage.'};const b=await getBuffer(media,ctx.config.maxMediaBytes);const out=await temp(ctx,'png');try{fs.writeFileSync(out,await stickerToImage(b),{mode:0o600});await ctx.sock.sendMessage(ctx.jid,{image:{url:out},caption:'Converted from sticker.'},{quoted:ctx.message});return {ok:true,sent:true};}finally{fs.rmSync(out,{force:true});}}),
  cmd('mediainfo','Show information about replied media','.mediainfo (reply to media)',async ctx=>{const media=quotedMedia(ctx);if(!media)return {ok:false,message:'Reply to an image, video, sticker, or audio with .mediainfo.'};const m=media.message;return {ok:true,message:`📁 Type: ${media.type}\nMIME: ${m.mimetype||'unknown'}\nSize: ${m.fileLength?`${Math.ceil(Number(m.fileLength)/1024)} KB`:'not provided'}\nDuration: ${m.seconds?`${m.seconds} sec`:'—'}\nCaption: ${m.caption||'—'}`};}),
  cmd('savestatus','Save an image/video status by replying to that status with this command','.savestatus (reply to a status)',async ctx=>{
    if(!ctx.isOwner)return {ok:false,message:'Only the verified owner can save statuses.'};const media=quotedMedia(ctx);if(!media||!['image','video'].includes(media.type))return {ok:false,message:'Reply directly to a photo or video status with .savestatus. WhatsApp must provide the quoted media to the bot.'};
    let b;try{b=await getBuffer(media,ctx.config.maxMediaBytes);}catch(error){return {ok:false,message:`Status download failed (${safeMediaCode(error)}).`};}const ext=media.type==='image'?'jpg':'mp4',file=await temp(ctx,ext);try{fs.writeFileSync(file,b,{mode:0o600});const target=`${ctx.senderNumber||ctx.config.ownerNumber}@s.whatsapp.net`;await ctx.sock.sendMessage(target,media.type==='image'?{image:{url:file},caption:'Saved status photo'}:{video:{url:file},caption:'Saved status video'},{messageId:undefined});return {ok:true,message:'📤 Status media submitted to your private chat; visible delivery is not confirmed.',sentToOwner:true};}finally{fs.rmSync(file,{force:true});}
  },{ownerOnly:true}),
  cmd('status','List status features and privacy limits','.status',async()=>({ok:true,message:'📸 *Status tools*\n• .statusview on|off — auto views\n• .statuslike on|off — fixed-heart reactions\n• .statusstats — delivery diagnostics\n• .statusreact on|off — automatic reactions to new statuses\n• .savestatus — reply to a photo/video status where WhatsApp includes the quoted media\n\nI cannot retrieve hidden/expired statuses or bypass WhatsApp privacy settings. Status media is temporary and removed after delivery.'})),
  cmd('gif','Search a GIF by phrase (requires GIPHY_API_KEY)','.gif search terms',async(ctx,args)=>{if(!ctx.config.giphyApiKey)return {ok:false,message:'GIF search needs optional GIPHY_API_KEY.'};const q=args.join(' ');if(!q)return {ok:false,message:'Usage: .gif search terms'};const url=new URL('https://api.giphy.com/v1/gifs/search');url.search=new URLSearchParams({api_key:ctx.config.giphyApiKey,q,limit:'1',rating:'pg'});const r=await fetch(url);if(!r.ok)throw new Error('GIF provider request failed');const data=await r.json();const gif=data.data?.[0]?.images?.original?.mp4;if(!gif)return {ok:true,message:'No GIF result found.'};await ctx.sock.sendMessage(ctx.jid,{video:{url:gif},gifPlayback:true,caption:`GIF: ${q}`},{quoted:ctx.message});return {ok:true,sent:true};}),
  cmd('movie','Find movie details from TMDB (metadata only)','.movie title',async(ctx,args)=>{if(!ctx.config.tmdbApiKey)return {ok:false,message:'Movie search needs optional TMDB_API_KEY. TMDB provides metadata, not movie downloads.'};const q=args.join(' ');if(!q)return {ok:false,message:'Usage: .movie movie title'};const u=new URL('https://api.themoviedb.org/3/search/movie');u.search=new URLSearchParams({api_key:ctx.config.tmdbApiKey,query:q});const r=await fetch(u);if(!r.ok)throw new Error('TMDB request failed');const d=await r.json(),m=d.results?.[0];return {ok:true,message:m?`🎬 *${m.title}* (${(m.release_date||'').slice(0,4)||'year unknown'})\n⭐ ${m.vote_average||'—'}/10\n${m.overview||'No overview available.'}\n\nTMDB supplies movie information, not downloadable movie files.`:'No movie result found.'};}),
  cmd('music','Search for a song/artist using Genius (metadata/page links only)','.music song or artist',async(ctx,args)=>{if(!ctx.config.geniusToken)return {ok:false,message:'Music search needs optional GENIUS_ACCESS_TOKEN. This finds song pages; it does not download music.'};const q=args.join(' ');if(!q)return {ok:false,message:'Usage: .music song or artist'};const r=await fetch(`https://api.genius.com/search?q=${encodeURIComponent(q)}`,{headers:{Authorization:`Bearer ${ctx.config.geniusToken}`}});if(!r.ok)throw new Error('Genius request failed');const d=await r.json(),h=d.response?.hits?.[0]?.result;return {ok:true,message:h?`🎵 *${h.title}* — ${h.primary_artist.name}\n${h.url}\n\nThis is a song information page, not an MP3 download.`:'No song page found.'};}),
  cmd('identify','Identify a song from replied audio using AudD','.identify (reply to audio)',async ctx=>{if(!ctx.config.auddToken)return {ok:false,message:'Song identification needs optional AUDD_API_TOKEN.'};const media=quotedMedia(ctx);if(media?.type!=='audio')return {ok:false,message:'Reply to an audio clip with .identify.'};const bytes=await getBuffer(media,ctx.config.maxMediaBytes);return identifySong(ctx.config.auddToken,bytes,media.message.mimetype||'audio/ogg');}),
  cmd('audioconvert','Convert replied audio to MP3 with FFmpeg','.audioconvert (reply to audio)',async(ctx)=>{const media=quotedMedia(ctx);if(media?.type!=='audio')return {ok:false,message:'Reply to an audio message with .audioconvert.'};const b=await getBuffer(media,ctx.config.maxMediaBytes),src=await temp(ctx,'input'),out=await temp(ctx,'mp3');try{fs.writeFileSync(src,b,{mode:0o600});await ffmpeg(['-y','-i',src,'-vn','-codec:a','libmp3lame','-q:a','4',out]);await ctx.sock.sendMessage(ctx.jid,{audio:{url:out},mimetype:'audio/mpeg',fileName:'converted.mp3'},{quoted:ctx.message});return {ok:true,sent:true};}finally{fs.rmSync(src,{force:true});fs.rmSync(out,{force:true});}})
];

module.exports.mediaHelpers={quotedMedia,getBuffer,imageToSticker,stickerToImage,availableMedia,availableQuotedMedia,forwardAvailableMedia};
