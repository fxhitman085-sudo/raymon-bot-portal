const { jidNormalizedUser } = require('@whiskeysockets/baileys');
const { isOwnerNumber } = require('../lib/ownership');

const phonePattern = /^[1-9]\d{7,14}$/;
const fail = message => ({ ok: false, message });

async function contact(ctx, args) {
  if (args.length === 1 && phonePattern.test(args[0].replace(/^\+/, ''))) {
    const number = args[0].replace(/^\+/, '');
    return { number, jid: `${number}@s.whatsapp.net` };
  }
  if (args.length) return null;
  const jid = jidNormalizedUser(ctx.quoted?.participant || ctx.quoted?.key?.participant || '');
  const [number, server] = jid.split('@');
  if (server === 's.whatsapp.net' && phonePattern.test(number)) return { number, jid };
  if (server !== 'lid' || !/^\d+$/.test(number)) return null;
  const mapping = ctx.sock?.signalRepository?.lidMapping;
  let phoneJid;
  try { phoneJid = jidNormalizedUser(await mapping?.getPNForLID?.(jid) || ''); }
  catch { return null; }
  const [phone, phoneServer] = phoneJid.split('@');
  return phoneServer === 's.whatsapp.net' && phonePattern.test(phone) ? { number: phone, jid } : null;
}

const restrictions = ['ban', 'unban'].map(name => ({
  name, description: name === 'ban' ? 'Pause a user’s bot access' : 'Restore a user’s bot access',
  usage: `.${name} [country-code-number] (or reply to a message)`,
  category: 'Owner controls', mainOwnerOnly: true, allowPrivate: true, prefixOnly: true, hidden: true,
  async execute(ctx, args) {
    if (!ctx.sessions?.ownerSocket(ctx)) return fail('Use this command from the main bot or your own linked bot account.');
    const target = await contact(ctx, args);
    if (!target) return fail(`Reply to a user’s message or use ${ctx.prefix || '.'}${name} followed by their number with the country code. If the reply can’t be identified, use the number.`);
    return ctx.sessions.setBan(target.number, name === 'ban', target.jid);
  }
}));

module.exports = [...restrictions, {
  name: 'say cheese', description: 'Block a contact on your linked WhatsApp account',
  usage: '.say cheese [country-code-number] (or reply to a message)', category: 'Owner controls',
  ownerOnly: true, prefixOnly: true,
  async execute(ctx, args) {
    const own = jidNormalizedUser(ctx.sock?.user?.id || '');
    const ownLid = jidNormalizedUser(ctx.botLid || ctx.sock?.user?.lid || '');
    const from = jidNormalizedUser(ctx.sender || '');
    if (!ctx.message?.key?.fromMe || !isOwnerNumber(ctx.config, ctx.senderNumber) || !from || (from !== own && from !== ownLid))
      return fail('Send this command from your own linked WhatsApp account.');
    if (!ctx.sock?.updateBlockStatus) return fail('WhatsApp blocking is unavailable on this connection.');
    const target = await contact(ctx, args);
    if (!target) return fail(`Reply to a contact’s message or use ${ctx.prefix || '.'}say cheese followed by their number with the country code.`);
    if (target.jid === own || target.jid === ownLid || target.number === ctx.senderNumber) return fail('Choose another contact to block.');
    if (ctx.isPaused?.()) return { ok: false, sent: true };
    try {
      await ctx.sock.updateBlockStatus(target.jid, 'block');
    } catch {
      return fail('WhatsApp could not block that contact. Try again by replying to a recent message from them.');
    }
    return { ok: true, message: 'Contact blocked on your WhatsApp account.' };
  }
}];
