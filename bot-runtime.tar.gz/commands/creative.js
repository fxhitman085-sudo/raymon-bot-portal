const fs = require('node:fs/promises');
const sharp = require('sharp');

const megabyte = 1024 * 1024;
const pictureLimit = 8 * megabyte;
const audioLimit = 16 * megabyte;
const inputFormats = 'aac,amr,flac,matroska,webm,mov,mp4,m4a,3gp,3g2,mj2,mp3,ogg,wav';
const voiceEffects = new Map([
  ['trailer', 'aresample=48000,asetrate=36000,aresample=48000,atempo=1.25,aecho=0.8:0.75:42:0.22'],
  ['robot', 'aresample=48000,highpass=f=250,lowpass=f=3000,tremolo=f=42:d=0.85,aecho=0.8:0.65:35:0.32'],
  ['chipmunk', 'aresample=48000,asetrate=67200,aresample=48000']
]);
const posterStyles = new Map([
  ['matchday', { label: 'MATCHDAY', accent: '#a8ff68', ink: '#080e0b' }],
  ['premiere', { label: 'MOVIE PREMIERE', accent: '#f8d387', ink: '#110e15' }],
  ['wanted', { label: 'WANTED', accent: '#ffc08b', ink: '#23120c' }]
]);
const captionStyles = new Map([
  ['clean', 'polished and natural'],
  ['funny', 'playful, with light jokes'],
  ['cold', 'confident, low-key and punchy'],
  ['naija', 'natural Nigerian Pidgin or Naija slang']
]);

const fail = message => ({ ok: false, message });
const cmd = (name, description, usage, execute) => ({
  name, description, usage, category: 'Media tools', prefixOnly: true, execute
});
const prefix = ctx => ctx.prefix || ctx.config.prefix || '.';
const xml = text => text.replace(/[&<>"']/g, char => ({
  '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&apos;'
})[char]);
const clean = text => String(text || '').replace(/[\p{Cc}\uFFFE\uFFFF]/gu, ' ').replace(/\s+/gu, ' ').trim();
const segmenter = new Intl.Segmenter(undefined, { granularity: 'grapheme' });

function openPhoto(bytes) {
  const jpeg = bytes[0] === 0xff && bytes[1] === 0xd8;
  const png = bytes.subarray(0, 8).equals(Buffer.from('89504e470d0a1a0a', 'hex'));
  const webp = bytes.toString('ascii', 0, 4) === 'RIFF' && bytes.toString('ascii', 8, 12) === 'WEBP';
  if (!jpeg && !png && !webp) throw new Error('Unsupported photo format');
  return sharp(bytes, { limitInputPixels: 20_000_000 }).autoOrient();
}

function textLines(text, width, limit) {
  const lines = [];
  const units = [...segmenter.segment(text)].map(({ segment }) => ({
    segment, width: /^[\x20-\x7e]$/.test(segment) ? 1 : 2
  }));
  let start = 0;
  while (start < units.length && lines.length < limit) {
    let end = start, columns = 0, lastSpace = -1;
    while (end < units.length && columns + units[end].width <= width) {
      if (units[end].segment === ' ') lastSpace = end;
      columns += units[end++].width;
    }
    if (end < units.length && units[end].segment !== ' ' && lastSpace > start) end = lastSpace;
    lines.push(units.slice(start, end).map(({ segment }) => segment).join('').trimEnd());
    start = end + (units[end]?.segment === ' ' ? 1 : 0);
  }
  if (start < units.length) lines[limit - 1] += '…';
  return lines;
}

function quoteSticker(text) {
  const lines = textLines(text, 25, 6);
  const height = 100 + lines.length * 37;
  const top = Math.round((512 - height) / 2);
  const quote = lines.map((line, index) =>
    '<text x="69" y="' + (top + 87 + index * 37) + '">' + xml(line) + '</text>').join('');
  const svg = '<svg xmlns="http://www.w3.org/2000/svg" width="512" height="512">' +
    '<path d="M50 ' + (top + height - 48) + 'L21 ' + (top + height - 10) + 'L58 ' + (top + height - 14) + 'Z" fill="#103f35"/>' +
    '<rect x="39" y="' + top + '" width="432" height="' + height + '" rx="26" fill="#103f35"/>' +
    '<rect x="54" y="' + (top + 26) + '" width="5" height="' + (height - 52) + '" rx="2" fill="#73e0a8"/>' +
    '<text x="69" y="' + (top + 46) + '" fill="#9ef0bf" font-family="sans-serif" font-weight="700" font-size="19">QUOTED MESSAGE</text>' +
    '<g font-family="monospace" font-size="24" fill="#ffffff">' + quote + '</g></svg>';
  return sharp(Buffer.from(svg)).webp({ quality: 80 }).toBuffer();
}

async function makePoster(photo, style, title) {
  const lines = textLines(title, 21, 3);
  const heading = lines.map((line, index) =>
    '<text x="58" y="' + (822 - (lines.length - 1 - index) * 63) + '">' + xml(line) + '</text>').join('');
  const svg = '<svg xmlns="http://www.w3.org/2000/svg" width="768" height="960">' +
    '<defs><linearGradient id="fade" x1="0%" x2="0%" y1="0%" y2="100%">' +
    '<stop offset="30%" stop-color="' + style.ink + '" stop-opacity="0"/><stop offset="100%" stop-color="' + style.ink + '"/>' +
    '</linearGradient></defs><rect width="768" height="960" fill="url(#fade)"/>' +
    '<rect x="26" y="26" width="716" height="908" rx="14" fill="none" stroke="' + style.accent + '" stroke-width="2"/>' +
    '<rect x="57" y="56" width="272" height="52" rx="7" fill="' + style.accent + '"/>' +
    '<text x="76" y="90" fill="' + style.ink + '" font-family="sans-serif" font-size="25" font-weight="800">' + style.label + '</text>' +
    '<g fill="#ffffff" font-family="monospace" font-size="48" font-weight="800">' + heading + '</g>' +
    '<path d="M58 859H705" stroke="' + style.accent + '" stroke-width="3"/>' +
    '<text x="58" y="903" fill="' + style.accent + '" font-family="sans-serif" font-size="20" font-weight="700">RAYMON BOT  /  POSTER STUDIO</text></svg>';
  return openPhoto(photo).resize(768, 960, { fit: 'cover' })
    .composite([{ input: Buffer.from(svg) }]).jpeg({ quality: 85 }).toBuffer();
}

module.exports = function creativeCommands({ quotedMedia, getBuffer, ffmpeg, temp, identifySong }) {
  let activeJobs = 0;

  async function mediaJob(ctx, types, instruction, limit, work) {
    let media;
    try { media = quotedMedia(ctx); } catch { return fail('Reply to regular media for this command.'); }
    if (!media || !types.includes(media.type) || media.message.viewOnce) return fail(instruction);
    if (Number(media.message.fileLength) > limit) return fail('This file is too large for that command.');
    if (activeJobs >= 2) return fail('The media tools are busy. Try again in a moment.');
    activeJobs++;
    try {
      const input = await getBuffer(media, limit);
      return await work(input, media);
    } catch (error) {
      if (error.code === 'FFMPEG_MISSING') return fail('This command needs FFmpeg on the bot host.');
      if (error.safeCode === 'MEDIA_TOO_LARGE') return fail('This file is too large for that command.');
      return fail('I couldn’t process or send that media. Try another clip or photo.');
    } finally {
      activeJobs--;
    }
  }

  async function audioClip(ctx, input, seconds, options, extension) {
    const source = await temp(ctx, 'input');
    const output = await temp(ctx, extension);
    try {
      await fs.writeFile(source, input, { mode: 0o600 });
      await ffmpeg([
        '-nostdin', '-y', '-threads', '1', '-protocol_whitelist', 'file',
        '-format_whitelist', inputFormats, '-i', source, '-map', '0:a:0',
        '-vn', '-sn', '-dn', '-t', String(seconds), '-ac', '1', ...options, output
      ], 30_000);
      return await fs.readFile(output);
    } finally {
      await Promise.all([source, output].map(file => fs.rm(file, { force: true })));
    }
  }

  async function send(ctx, payload) {
    await ctx.sock.sendMessage(ctx.jid, payload, { quoted: ctx.message });
    return { ok: true, sent: true };
  }

  return [
    cmd('voicefx', 'Remix a replied voice note', '.voicefx trailer|robot|chipmunk', async (ctx, args) => {
      const effect = args[0]?.toLowerCase() || 'trailer';
      if (args.length > 1 || !voiceEffects.has(effect)) return fail('Use ' + prefix(ctx) + 'voicefx trailer, robot, or chipmunk.');
      return mediaJob(ctx, ['audio'], 'Reply to a voice note or audio clip with ' + prefix(ctx) + 'voicefx ' + effect + '.',
        Math.min(audioLimit, ctx.config.maxMediaBytes || audioLimit), async input => {
          const audio = await audioClip(ctx, input, 45, ['-af', voiceEffects.get(effect), '-c:a', 'libopus', '-b:a', '32k'], 'ogg');
          return send(ctx, { audio, ptt: true, mimetype: 'audio/ogg; codecs=opus' });
        });
    }),
    cmd('quotesticker', 'Make a WhatsApp-style sticker from quoted text', '.quotesticker (reply to text)', async (ctx, args) => {
      const message = ctx.quoted?.message || ctx.quotedMessage;
      const quoted = message?.ephemeralMessage?.message || message;
      const text = clean(quoted?.conversation || quoted?.extendedTextMessage?.text).slice(0, 1000);
      if (args.length || !text) return fail('Reply to a text message with ' + prefix(ctx) + 'quotesticker.');
      return send(ctx, { sticker: await quoteSticker(text) });
    }),
    cmd('poster', 'Turn a photo into a matchday, premiere, or wanted poster', '.poster matchday|premiere|wanted title', async (ctx, args) => {
      const style = posterStyles.get(args[0]?.toLowerCase());
      const title = clean(args.slice(1).join(' '));
      if (!style || !title || [...title].length > 63) return fail('Reply to a photo with ' + prefix(ctx) + 'poster matchday|premiere|wanted followed by a title of up to 63 characters.');
      return mediaJob(ctx, ['image'], 'Reply to a photo to make a poster.', Math.min(pictureLimit, ctx.config.maxMediaBytes || pictureLimit), async input => {
        return send(ctx, { image: await makePoster(input, style, title), caption: style.label + ' • ' + title });
      });
    }),
    cmd('caption', 'Get three captions based on a replied photo', '.caption [clean|funny|cold|naija]', async (ctx, args) => {
      const style = captionStyles.get(args[0]?.toLowerCase() || 'clean');
      if (args.length > 1 || !style) return fail('Use ' + prefix(ctx) + 'caption clean, funny, cold, or naija.');
      if (!ctx.ai?.available) return fail('Photo captions need GEMINI_API_KEY on the bot host.');
      return mediaJob(ctx, ['image'], 'Reply to a photo to get caption ideas.', Math.min(pictureLimit, ctx.config.maxMediaBytes || pictureLimit), async input => {
        const image = await openPhoto(input)
          .resize(1024, 1024, { fit: 'inside', withoutEnlargement: true }).flatten({ background: '#ffffff' }).jpeg({ quality: 80 }).toBuffer();
        let captions;
        try { captions = await ctx.ai.captionImage(image, style); }
        catch { return fail('Gemini could not generate captions for this photo. Try again in a moment.'); }
        return { ok: true, list: true, message: captions.map((line, index) => (index + 1) + '. ' + line).join('\n') };
      });
    }),
    cmd('songid', 'Identify a song from a replied audio or video clip', '.songid (reply to audio/video)', async (ctx, args) => {
      if (args.length) return fail('Reply to an audio or video clip with ' + prefix(ctx) + 'songid.');
      if (!ctx.config.auddToken) return fail('Song identification needs AUDD_API_TOKEN on the bot host.');
      return mediaJob(ctx, ['audio', 'video'], 'Reply to an audio or video clip with ' + prefix(ctx) + 'songid.',
        Math.min(audioLimit, ctx.config.maxMediaBytes || audioLimit), async (input, media) => {
          const seconds = Number(media.message.seconds);
          const shortAudio = media.type === 'audio' && seconds > 0 && seconds <= 12 && input.length <= 2 * megabyte;
          const clip = shortAudio ? input : await audioClip(ctx, input, 12, ['-ar', '24000', '-c:a', 'libmp3lame', '-b:a', '48k'], 'mp3');
          try {
            return await identifySong(ctx.config.auddToken, clip, shortAudio ? media.message.mimetype || 'audio/ogg' : 'audio/mpeg');
          } catch {
            return fail('AudD could not complete song recognition. Check the token or try again later.');
          }
        });
    })
  ];
};
