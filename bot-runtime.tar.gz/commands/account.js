const {jidNormalizedUser}=require('@whiskeysockets/baileys');
const {spawnSync}=require('node:child_process');
const {sendList}=require('../lib/presentation');
const cmd=(name,description,usage,execute)=>({name,description,usage,category:'Account controls',ownerOnly:true,execute});
function validEmoji(value){return typeof value==='string'&&value.length<=32&&[...new Intl.Segmenter(undefined,{granularity:'grapheme'}).segment(value)].length===1&&/\p{Extended_Pictographic}|\p{Regional_Indicator}|[0-9#*]\uFE0F?\u20E3/u.test(value);}
const on=value=>value?'ON':'OFF';
const duration=ms=>{const s=Math.max(0,Math.floor(ms/1000));return `${Math.floor(s/3600)}h ${Math.floor(s%3600/60)}m ${s%60}s`;};
let ffmpeg;
function hasFFmpeg(){if(!ffmpeg||Date.now()-ffmpeg.at>600000){const result=spawnSync('ffmpeg',['-version'],{timeout:1500,stdio:'ignore'});ffmpeg={at:Date.now(),ok:result.status===0};}return ffmpeg.ok;}
async function dashboard(ctx){
 const db=ctx.db,settings=ctx.away?.reconcile?.()||db.get('away.settings',{}),sock=ctx.sock;
 const own=jidNormalizedUser(sock?.user?.id||ctx.botJid||''),aliases=[...new Set([`${ctx.config.ownerNumber}@s.whatsapp.net`,...(own===`${ctx.config.ownerNumber}@s.whatsapp.net`?[own,jidNormalizedUser(ctx.botLid||sock?.user?.lid||'')]:[])].filter(Boolean))];
 const scores=aliases.map(id=>db.scoreFor?.(id)).filter(Boolean);const score=scores.reduce((a,b)=>({points:a.points+b.points,wins:a.wins+b.wins}),{points:0,wins:0});
 const groups=ctx.getGroupCount?await ctx.getGroupCount():ctx.groupCount;
 const top=db.commandStats?.(5)||[];const game=ctx.games?.summary?.(ctx.jid);
 const integration=[['Gemini',ctx.ai?.available],['TMDB',ctx.config.tmdbApiKey],['GIPHY',ctx.config.giphyApiKey],['Genius',ctx.config.geniusToken],['AudD',ctx.config.auddToken]].map(([name,ready])=>`${name}: ${ready?'configured':'not configured'}`).join('\n');
 const exclusions=db.get('statusExclusions',[]);const group=ctx.isGroup?db.group?.(ctx.jid):null;
 const groupInfo=group?`\n\n*Current group configuration*\nAnti-link: ${on(group.antilink)} • Anti-spam: ${on(group.antispam)}\nAnti-flood: ${on(group.antiflood)}\nWelcome: ${on(group.welcome)} • Goodbye: ${on(group.goodbye)}\nRules: ${String(group.rules||'not set').slice(0,500)}`:'';
 const text=`🔐 *RAYMON BOT — ACCOUNT DASHBOARD*\n\n*Account*\nName: ${String(sock?.user?.name||sock?.user?.verifiedName||'Not provided').slice(0,120)}\nNumber: ${own.endsWith('@s.whatsapp.net')?own.split('@')[0]:'Not available'}\nOwner number: ${ctx.config.ownerNumber||'Not configured'}\nConnection: ${ctx.connected?'connected':'disconnected'}\nAccount runtime: ${ctx.accountStartedAt?duration(Date.now()-ctx.accountStartedAt):'not available'}\nCurrent connection: ${ctx.connectedAt?duration(Date.now()-ctx.connectedAt):'not available'}\nMode: ${db.get('mode','private')}\nPrefix: ${ctx.config.prefix||'.'}\nCommand reaction: ${db.get('commandReaction','⚡')||'OFF'}\n\n*Away replies*\nEnabled: ${on(settings.enabled)} • Away: ${on(settings.active)}\nAutomatic after 15 minutes: ${on(settings.automatic)}\nLast manual activity: ${settings.lastActivity?new Date(settings.lastActivity).toISOString():'not recorded'}\nMessage: ${settings.message||'not configured'}\n\n*AI and status*\nAI auto replies: ${on(db.get('autoReply',false))}\nStatus reaction style: ${db.get('statusReactionStyle','heart')}\nStatus views: ${on(db.get('statusView',false))}\nStatus reactions: ${on(db.get('statusReact',false))}\nStatus reaction style: ${db.get('statusReactionStyle','heart')}\nStatus emoji mode: ${db.get('statusEmojiMode','random')}\nFixed emoji: ${db.get('statusEmoji','❤️')}\nSelected emojis: ${db.get('statusEmojis',ctx.config.statusEmojis||[]).join(' ')}\nExcluded contacts: ${exclusions.length}${exclusions.length?` — ${exclusions.slice(0,20).join(', ')}${exclusions.length>20?' …':''}`:''}\nStatus received: ${db.stat('status.received')}\nReaction submissions: ${db.stat('status.reactions')}\nServer accepted/rejected: ${db.stat('status.accepted')}/${db.stat('status.rejected')}\nLast status result: ${db.get('status.lastResult','No attempt yet')}\n\n*Usage and games*\nConnected groups: ${groups??'not available'}\nMessages processed: ${db.stat('messages.received')}\nCommands processed: ${db.stat('commands.total')}\nRegistered commands: ${ctx.commandMap?.size||0}\nMost used: ${top.length?top.map(r=>`${r.name} (${r.count})`).join(', '):'none yet'}\nYour game points: ${score.points} • Wins: ${score.wins}\nGames completed: ${db.stat('games.completed')}\nCurrent chat game: ${game||'none'}\nActive games on this account: ${ctx.games?.count?.()||0}\n\n*Capabilities*\nView-once/media forwarding command: ${on(db.get('feature.vv',true))}\nImage stickers/conversion: available (Sharp)\nAnimated stickers/audio conversion: ${hasFFmpeg()?'FFmpeg available':'FFmpeg unavailable'}\nTranslation: ${ctx.ai?.available?'Gemini configured':'requires GEMINI_API_KEY'}\n${integration}\n\n*Quick controls*\n.settings • .setreaction 🔥 • .mode private|public\n.away • .back • .offlinereply on|off\n.statuslike on|off • .statusreact on|off • .autoreply on|off\n.help command • .leaderboard • .restart\n\nStatus submissions and server acceptance do not prove visible delivery.${groupInfo}`;
 const target=ctx.isGroup?`${ctx.config.ownerNumber}@s.whatsapp.net`:ctx.jid;
 if(!sock?.sendMessage)return {ok:true,message:text};
 return sendList(ctx,text,{target});
}
module.exports=[
 cmd('setreaction','Choose your account’s command reaction emoji or disable it','.setreaction [emoji|off]',async(ctx,args)=>{
  if(!args.length)return {ok:true,message:`Command reaction: ${ctx.db.get('commandReaction','⚡')||'OFF'}\nUsage: .setreaction 🔥 | .setreaction off`};
  const value=args.join(' ').trim();if(value.toLowerCase()==='off'){ctx.db.set('commandReaction','');return {ok:true,message:'Command reactions disabled for your account.'};}
  if(!validEmoji(value))return {ok:false,message:'Choose exactly one emoji. Example: .setreaction 🔥'};
  ctx.db.set('commandReaction',value);return {ok:true,message:`Your command reaction is now ${value}.`};
 }),
 cmd('dashboard','Show detailed private information and controls for your own linked account','.dashboard',dashboard)
];
module.exports.validEmoji=validEmoji;
