module.exports=[{
 name:'announce',description:'Send a private announcement to registered bot users',usage:'.announce message',category:'Main owner',hidden:true,mainOwnerOnly:true,allowPrivate:true,prefixOnly:true,
 async execute(ctx,args){
  if(!ctx.updates)return {ok:false,message:'The announcement service is unavailable in this session.'};
  const result=ctx.updates.announce(ctx,args.join(' '));
  return result.ok?{ok:true,message:`Announcement queued for ${result.count} registered user(s), including users with automatic update alerts off. Messages will be sent privately as their linked account becomes available. Queued does not mean delivered.`}:result;
 }
}];
