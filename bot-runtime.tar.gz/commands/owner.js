const cmd = (name, description, usage, execute) => ({ name, description, usage, category:'Owner controls', ownerOnly:true, execute });
const onOff = value => ['on','off'].includes(String(value).toLowerCase());

module.exports = [
  ...require('./away'),
  ...require('./account'),
  ...['disable','enable'].map(action=>cmd(action,`${action} the owner media forwarding command`,`.${action} .vv`,async(ctx,args)=>{
    const prefix=ctx.prefix||'.',target=args[0]||'';
    const name=target.startsWith(prefix)?target.slice(prefix.length):target.replace(/^\./,'');
    if(args.length!==1||name.toLowerCase()!=='vv')return {ok:false,message:`Usage: ${prefix}${action} ${prefix}vv`};
    ctx.db.set('feature.vv',action==='enable');return {ok:true,message:`${prefix}vv is now ${action==='enable'?'enabled':'disabled'}.`};
  })),
  cmd('pair','Link an additional WhatsApp account','.pair country-code-number',async(ctx,args)=>args.length!==1?{ok:false,message:'Usage: .pair country-code-number (one number, digits only).'}:ctx.sessions?ctx.sessions.pair(ctx,args[0]):{ok:false,message:'Pairing is only available on the main bot.'}),
  {name:'reconnect',description:'Retry saved sessions for disconnected linked accounts',usage:'.reconnect',category:'Owner controls',mainOwnerOnly:true,prefixOnly:true,hidden:true,execute:async(ctx,args)=>{
    if(args.length)return {ok:false,message:`Usage: ${ctx.prefix||'.'}reconnect`};
    return ctx.sessions?.reconnect?ctx.sessions.reconnect(ctx):{ok:false,message:'Session recovery is only available on the main bot.'};
  }},
  cmd('statusview','Toggle automatic viewing of received statuses','.statusview on|off',async(ctx,args)=>{
    if(!onOff(args[0]))return {ok:false,message:'Usage: .statusview on or .statusview off'};
    ctx.db.set('statusView',args[0].toLowerCase()==='on');return {ok:true,message:`Status viewing is ${args[0].toUpperCase()}.`};
  }),
  cmd('statuslike','Enable fixed-heart status reactions or disable reactions','.statuslike on|off',async(ctx,args)=>{
    if(args.length!==1||!onOff(args[0]))return {ok:false,message:'Usage: .statuslike on or .statuslike off'};
    const enabled=args[0].toLowerCase()==='on';ctx.db.set('statusReactionStyle','heart');ctx.db.set('statusReact',enabled);
    if(enabled)ctx.db.set('statusView',true);
    return {ok:true,message:enabled?'Automatic status viewing and heart reactions are ON. Use .statusstats to check server acceptance; confirm the visible like with the status poster.':'Automatic status reactions are OFF. Status viewing keeps its separate setting.'};
  }),
  cmd('statusstats','Show status delivery diagnostics','.statusstats',async ctx=>({ok:true,message:`📸 *Status diagnostics*\nView: ${ctx.db.get('statusView',false)?'ON':'OFF'} • React: ${ctx.db.get('statusReact',false)?'ON':'OFF'}\nStyle: ${ctx.db.get('statusReactionStyle','heart')==='heart'?'fixed heart':'custom emoji'}\nReceived events: ${ctx.db.stat('status.received')}\nView requests (unconfirmed): ${ctx.db.stat('status.views')}\nView failures: ${ctx.db.stat('status.viewFailures')}\nReaction requests (unconfirmed): ${ctx.db.stat('status.reactions')}\nHeart requests: ${ctx.db.stat('status.heartRequests')}\nServer accepted: ${ctx.db.stat('status.accepted')}\nServer rejected: ${ctx.db.stat('status.rejected')}\nNo acceptance received: ${ctx.db.stat('status.unconfirmed')}\nAwaiting acceptance: ${ctx.db.get('status.pendingAcks',[]).length}\nFailures: ${ctx.db.stat('status.failures')}\nRate limited: ${ctx.db.stat('status.rateLimited')}\nLast result: ${ctx.db.get('status.lastResult','No attempt yet')}\nServer acceptance does not confirm a visible native like. Only statuses delivered to this linked device can be handled. Limit: 30/hour.`})),
  {...cmd('owner','Show who owns RAYMON BOT','.owner',async()=>({ok:true,message:'owned by HITMAN AKA Raymon requested by NAMELESS'})),ownerOnly:false},
  cmd('settings','Show current persistent settings','.settings',async ctx=>({ok:true,message:`⚙️ *Settings*\nMode: ${ctx.db.get('mode','private')}\nAuto status reactions: ${ctx.db.get('statusReact',false)?'on':'off'}\nStatus style: ${ctx.db.get('statusReactionStyle','heart')}\nEmoji mode: ${ctx.db.get('statusEmojiMode','random')}\nFixed emoji: ${ctx.db.get('statusEmoji','❤️')}\nSelected emojis: ${(ctx.db.get('statusEmojis',ctx.config.statusEmojis)).join(' ')}\nAuto replies: ${ctx.db.get('autoReply',false)?'on':'off'}\nExcluded status contacts: ${(ctx.db.get('statusExclusions',[])).length}`})),
  cmd('mode','Set private or public access','.mode private|public',async(ctx,args)=>{
    const mode=String(args[0]||'').toLowerCase(); if(!['private','public'].includes(mode)) return {ok:false,message:'Usage: .mode private or .mode public'};
    ctx.db.set('mode',mode); return {ok:true,message:`🔒 Mode set to *${mode.toUpperCase()}*.`};
  }),
  cmd('statusreact','Toggle automatic reactions to new statuses','.statusreact on|off',async(ctx,args)=>{
    if(!onOff(args[0])) return {ok:false,message:'Usage: .statusreact on or .statusreact off'};
    ctx.db.set('statusReact',args[0].toLowerCase()==='on'); return {ok:true,message:`Status reactions are now *${args[0].toUpperCase()}*.`};
  }),
  cmd('setemoji','Choose fixed/random reactions or a custom emoji list','.setemoji random | .setemoji fixed ❤️ | .setemoji list ❤️ 🔥',async(ctx,args)=>{
    const mode=String(args[0]||'').toLowerCase();
    if(mode==='random'){ctx.db.set('statusReactionStyle','emoji');ctx.db.set('statusEmojiMode','random');return {ok:true,message:'Custom emoji mode: status reactions will choose randomly from your selected emoji list. Use .statuslike on to return to heart reactions.'};}
    if(mode==='fixed' && args[1]){ctx.db.set('statusReactionStyle','emoji');ctx.db.set('statusEmojiMode','fixed');ctx.db.set('statusEmoji',args[1]);return {ok:true,message:`Custom emoji mode: fixed status reaction set to ${args[1]}.`};}
    if(mode==='list' && args.length>1){const values=args.slice(1).join(' ').match(/\p{Extended_Pictographic}(?:\uFE0F|\u200D\p{Extended_Pictographic})*/gu)||[]; if(!values.length)return {ok:false,message:'Add one or more emoji after “list”.'};ctx.db.set('statusReactionStyle','emoji');ctx.db.set('statusEmojis',[...new Set(values)].slice(0,20));return {ok:true,message:`Custom status emoji list: ${[...new Set(values)].slice(0,20).join(' ')}`};}
    return {ok:false,message:'Usage: .setemoji random, .setemoji fixed ❤️, or .setemoji list ❤️ 🔥'};
  }),
  cmd('autoreply','Toggle AI replies to direct messages and bot mentions','.autoreply on|off',async(ctx,args)=>{
    if(!onOff(args[0]))return {ok:false,message:'Usage: .autoreply on or .autoreply off'};ctx.db.set('autoReply',args[0].toLowerCase()==='on');return {ok:true,message:`AI auto replies are now *${args[0].toUpperCase()}*.`};
  }),
  cmd('statusexclude','Exclude a contact from status reactions by replying to their chat or entering a number','.statusexclude add|remove 234…',async(ctx,args)=>{
    const action=String(args[0]||'').toLowerCase(), number=(args[1]||'').replace(/\D/g,''); if(!['add','remove'].includes(action)||!number)return {ok:false,message:'Usage: .statusexclude add|remove 234…'};
    const list=ctx.db.get('statusExclusions',[]), next=action==='add'?[...new Set([...list,number])]:list.filter(n=>n!==number);ctx.db.set('statusExclusions',next);return {ok:true,message:`Contact ${number} ${action==='add'?'excluded from':'removed from exclusions'}.`};
  }),
  cmd('botstats','Show usage statistics','.botstats',async ctx=>({ok:true,message:`📊 *Bot statistics*\nUptime: ${formatDuration(process.uptime())}\nCommands: ${ctx.commandCount}\nGroups: ${ctx.groupCount}\nMessages handled: ${ctx.db.stat('messages.received')}\nStatus reaction requests: ${ctx.db.stat('status.reactions')}`})),
  cmd('restart','Reconnect only your account’s WhatsApp session','.restart',async(ctx,args)=>args.length?{ok:false,message:'Usage: .restart'}:ctx.restartSession?ctx.restartSession():{ok:false,message:'Session restart is unavailable in this context.'})
];
function formatDuration(seconds){const s=Math.floor(seconds),d=Math.floor(s/86400),h=Math.floor(s%86400/3600),m=Math.floor(s%3600/60);return[d&&`${d}d`,h&&`${h}h`,m&&`${m}m`,`${s%60}s`].filter(Boolean).join(' ')}
