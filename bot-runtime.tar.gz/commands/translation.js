const {content,chunks}=require('../lib/text');
function parse(ctx,args){
 const input=args.join(' ').trim(),quoted=content(ctx.quoted?.message||ctx.quotedMessage||{});
 const quotedText=quoted.conversation||quoted.extendedTextMessage?.text||quoted.imageMessage?.caption||quoted.videoMessage?.caption||quoted.documentMessage?.caption||'';
 const split=input.indexOf('|');let target,text;
 if(split>=0){target=input.slice(0,split).trim();text=input.slice(split+1).trim();}
 else if(quotedText){target=input;text=quotedText;}
 else{const quotedTarget=input.match(/^"([^"]+)"\s+([\s\S]+)$/);if(quotedTarget){target=quotedTarget[1];text=quotedTarget[2];}else{const match=input.match(/^(\S+)\s+([\s\S]+)$/);target=match?.[1];text=match?.[2];}}
 if(!target||target.length>80||!/[\p{L}]/u.test(target)||!/^[\p{L}\p{M}\p{N}\s()'.-]+$/u.test(target))throw new Error('Reply to text with .translate Portuguese, or use .translate French Your text. Multiword languages: .translate Brazilian Portuguese | Your text');
 if(!text?.trim())throw new Error('Provide text to translate, or reply directly to a text message.');
 if(text.length>6000)throw new Error('Translate up to 6000 characters at a time.');return {target,text};
}
module.exports=[{name:'translate',description:'Translate replied or supplied text to a requested language using Gemini',usage:'.translate language (reply) | .translate language text | .translate language name | text',category:'AI',execute:async(ctx,args)=>{
 let request;try{request=parse(ctx,args);}catch(error){return {ok:false,message:error.message};}
 if(!ctx.ai?.available||!ctx.ai.translate)return {ok:false,message:'Translation requires GEMINI_API_KEY configured for this bot.'};
 try{
  const out=await ctx.ai.translate(request.target,request.text);
  if(!out.supported)return {ok:false,message:'I could not identify or reliably translate into that language. Please specify its name or language code more clearly.'};
  const text=`*${out.sourceLanguage} → ${out.targetLanguage}*\n\n${out.translation}`;
  if(text.length<=3500||!ctx.sock?.sendMessage)return {ok:true,message:text};
  for(const part of chunks(text))await ctx.sock.sendMessage(ctx.jid,{text:part});
  return {ok:true,sent:true};
 }catch{ctx.logger?.warn?.('Translation request failed.');return {ok:false,message:'Translation could not be completed. The Gemini service may be unavailable or rate limited. Please try again.'};}
}}];
module.exports.parse=parse;
