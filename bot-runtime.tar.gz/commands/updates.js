const {renderRelease}=require('../lib/releases');
const {sendNotice}=require('../lib/presentation');
module.exports=[
 {name:'updates',description:'Read the latest RAYMON BOT release announcement',usage:'.updates',category:'Bot information',allowPrivate:true,execute:async(ctx,args)=>args.length?{ok:false,message:'Usage: .updates'}:ctx.sock?.sendMessage?sendNotice(ctx,renderRelease()):{ok:true,message:renderRelease()}},
 {name:'updatealerts',description:'Manage your own private update announcements (on by default)',usage:'.updatealerts [on|off]',category:'Bot information',allowPrivate:true,execute:async(ctx,args)=>{
  if(args.length>1||args.length&&!['on','off'].includes(args[0].toLowerCase()))return {ok:false,message:'Usage: .updatealerts, .updatealerts on, or .updatealerts off. This changes only your own preference.'};
  if(!ctx.updates)return {ok:false,message:'Automatic update alerts are unavailable in this session. Use .updates to read the latest announcement.'};
  const user=ctx.updates.settings(ctx,args.length?args[0].toLowerCase()==='on':undefined);
  return {ok:true,message:`Your automatic update alerts are ${user.enabled?'ON':'OFF'}. ${user.enabled?'New releases are announced privately, once per release.':'You will not receive new automatic update notices.'}\nYour preference stays saved after restarts. Use .updates whenever you want to read the latest notice.`};
 }}
];
