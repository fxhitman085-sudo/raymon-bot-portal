const cmd=(name,description,usage,execute,extra={})=>({name,description,usage,category:'Games & fun',...extra,execute});
const JOKES=['Why did the computer go to the doctor? It had a virus.','Why was the math book sad? It had too many problems.','What do you call a bear with no teeth? A gummy bear.'];
const FACTS=['Octopuses have three hearts.','A day on Venus is longer than its year.','Honey can remain edible for an exceptionally long time when sealed and stored well.'];

const gameCommands=['quiz','trivia','guess','riddle','scramble'].map(type=>cmd(type,`Open a turn-based ${type} game; register with .join and begin with .begin`,`.${type} start [rounds] [seconds] | .${type} stop`,async(ctx,args)=>{
 if(!ctx.games)return {ok:false,message:'The game service is unavailable.'};
 const action=String(args[0]||'').toLowerCase();
 if(action==='stop')return ctx.games.stopGame(ctx);
 // Keep former numeric quiz and guessing commands usable.
 if(type==='guess'&&/^\d+$/.test(action)){if(!ctx.games.summary(ctx.jid))return {ok:false,message:'Start a game with .guess start first.'};const handled=await ctx.games.reply(ctx,action,{legacy:true});return {ok:handled,sent:handled};}
 if(!action||action==='start'||type==='quiz'&&/^\d+$/.test(action))return ctx.games.start(ctx,type,action==='start'?args.slice(1):args);
 return {ok:false,message:`Usage: .${type} start [rounds 1–10] [seconds 10–180], then .join and .begin in groups.`};
},{groupOnly:type==='quiz'}));
const legacy=(name,description,usage)=>cmd(name,description,usage,async(ctx,args)=>{
 if(!ctx.games?.summary(ctx.jid))return {ok:false,message:'There is no active game in this chat.'};
 await ctx.games.reply(ctx,args.join(' '),{legacy:true});return {ok:true,sent:true};
},{hidden:true});
module.exports=[
 ...require('./hack'),...gameCommands,
 cmd('join','Register for the current group game','.join',async ctx=>ctx.games.join(ctx),{groupOnly:true}),
 cmd('leave','Leave an open game registration','.leave',async ctx=>ctx.games.leave(ctx),{groupOnly:true}),
 cmd('begin','Host, account owner or admin: begin the registered group game','.begin',async ctx=>ctx.games.begin(ctx),{groupOnly:true}),
 cmd('gamestop','Host, account owner or admin: stop the current game','.gamestop',async ctx=>ctx.games.stopGame(ctx)),
 cmd('quizstop','Stop the current game (legacy quiz command)','.quiz stop',async ctx=>ctx.games.stopGame(ctx),{hidden:true}),
 legacy('answer','Submit a quiz answer (direct replies are recommended)','.answer A|B|C|D'),
 legacy('triviaanswer','Submit a trivia answer (direct replies are recommended)','.triviaanswer answer'),
 legacy('riddleanswer','Submit a riddle answer (direct replies are recommended)','.riddleanswer answer'),
 cmd('leaderboard','Show persistent game scores and wins','.leaderboard',async ctx=>{const rows=ctx.db.leaderboard(10);return {ok:true,message:`🏆 *Game leaderboard*\n${rows.length?rows.map((r,i)=>`${i+1}. @${r.user.split('@')[0]} — ${r.points} point(s), ${r.wins} win(s)`).join('\n'):'No scores yet. Start a game.'}`,mentions:rows.map(r=>r.user)};}),
 cmd('joke','Tell a short joke','.joke',async()=>({ok:true,message:`😄 ${JOKES[Math.floor(Math.random()*JOKES.length)]}`})),
 cmd('fact','Share a random fun fact','.fact',async()=>({ok:true,message:`💡 ${FACTS[Math.floor(Math.random()*FACTS.length)]}`})),
 cmd('challenge','Send a light-hearted random challenge','.challenge',async()=>({ok:true,message:`🎯 Challenge: ${['Share one thing you learned today.','Name three countries in 10 seconds.','Send a kind message to someone.','Describe your day using only three emojis.'][Math.floor(Math.random()*4)]}`}))
];
