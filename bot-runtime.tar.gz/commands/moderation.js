const cmd=(name,description,usage,execute,extra={})=>({name,description,usage,category:'Group moderation',groupOnly:true,...extra,execute});
function targetFrom(ctx,args){
  const msg=ctx.message?.message||{}; const quoted=ctx.quoted?.participant||ctx.quoted?.sender;
  const mentioned=msg.extendedTextMessage?.contextInfo?.mentionedJid||[];
  const raw=args.find(x=>/^@?\d{6,}$/.test(x));
  return mentioned[0]||quoted||(raw?`${raw.replace(/\D/g,'')}@s.whatsapp.net`:null);
}
function groupConfig(ctx){return ctx.db.group(ctx.jid)}
function save(ctx,c){ctx.db.setGroup(ctx.jid,c)}
module.exports=[

  cmd('kick','Remove a mentioned or quoted member','.kick @member',async()=>({ok:false,message:'Mention a member.'})),
  cmd('promote','Promote a mentioned or quoted member to admin','.promote @member',async()=>({ok:false,message:'Mention a member.'})),
  cmd('demote','Remove admin rights from a mentioned or quoted member','.demote @member',async()=>({ok:false,message:'Mention a member.'})),
  cmd('warn','Warn a member; three warnings remove them when allowed','.warn @member [reason]',async(ctx,args)=>{
    const who=targetFrom(ctx,args); if(!who)return {ok:false,message:'Mention or reply to the member you want to warn.'};
    const count=ctx.db.warn(ctx.jid,who), reason=args.filter(a=>!/^@?\d{6,}$/.test(a)).join(' ')||'No reason given';
    if(count>=3){try{await ctx.sock.groupParticipantsUpdate(ctx.jid,[who],'remove');return {ok:true,message:`⚠️ @${who.split('@')[0]} received warning ${count} and has been removed. Reason: ${reason}`,mentions:[who]};}catch{return {ok:true,message:`⚠️ @${who.split('@')[0]} received warning ${count}. I couldn't remove them; check my group permissions.`,mentions:[who]};}}
    return {ok:true,message:`⚠️ Warning ${count}/3 for @${who.split('@')[0]}. Reason: ${reason}`,mentions:[who]};
  },{adminOnly:true,botAdmin:true}),
  cmd('antilink','Toggle anti-link moderation','.antilink on|off',async(ctx,args)=>{
    if(!['on','off'].includes(String(args[0]).toLowerCase()))return {ok:false,message:'Usage: .antilink on or .antilink off'};const c=groupConfig(ctx);c.antilink=args[0].toLowerCase()==='on';save(ctx,c);return {ok:true,message:`Anti-link is now ${c.antilink?'ON':'OFF'} in this group.`};
  },{adminOnly:true}),
  cmd('antispam','Toggle repeated-message spam checks','.antispam on|off',async(ctx,args)=>{
    if(!['on','off'].includes(String(args[0]).toLowerCase()))return {ok:false,message:'Usage: .antispam on or .antispam off'};const c=groupConfig(ctx);c.antispam=args[0].toLowerCase()==='on';save(ctx,c);return {ok:true,message:`Anti-spam is now ${c.antispam?'ON':'OFF'} in this group.`};
  },{adminOnly:true}),
  cmd('antiflood','Toggle message flood protection','.antiflood on|off',async(ctx,args)=>{
    if(!['on','off'].includes(String(args[0]).toLowerCase()))return {ok:false,message:'Usage: .antiflood on or .antiflood off'};const c=groupConfig(ctx);c.antiflood=args[0].toLowerCase()==='on';save(ctx,c);return {ok:true,message:`Anti-flood is now ${c.antiflood?'ON':'OFF'} in this group.`};
  },{adminOnly:true}),
  cmd('welcome','Toggle welcome messages','.welcome on|off',async(ctx,args)=>{
    if(!['on','off'].includes(String(args[0]).toLowerCase()))return {ok:false,message:'Usage: .welcome on or .welcome off'};const c=groupConfig(ctx);c.welcome=args[0].toLowerCase()==='on';save(ctx,c);return {ok:true,message:`Welcome messages are ${c.welcome?'ON':'OFF'}.`};
  },{adminOnly:true}),
  cmd('goodbye','Toggle goodbye messages','.goodbye on|off',async(ctx,args)=>{
    if(!['on','off'].includes(String(args[0]).toLowerCase()))return {ok:false,message:'Usage: .goodbye on or .goodbye off'};const c=groupConfig(ctx);c.goodbye=args[0].toLowerCase()==='on';save(ctx,c);return {ok:true,message:`Goodbye messages are ${c.goodbye?'ON':'OFF'}.`};
  },{adminOnly:true}),
  cmd('setrules','Set group rules','.setrules your rules…',async(ctx,args)=>{const text=args.join(' ').trim();if(!text)return {ok:false,message:'Add the group rules after .setrules.'};const c=groupConfig(ctx);c.rules=text.slice(0,1500);save(ctx,c);return {ok:true,message:'✅ Group rules saved.'};},{adminOnly:true}),
  cmd('rules','Show saved group rules','.rules',async ctx=>({ok:true,message:`📜 *Group rules*\n${groupConfig(ctx).rules||'No rules have been saved. A group admin can set them with .setrules.'}`})),
  cmd('grouplock','Only admins can send messages','.grouplock',async ctx=>{await ctx.sock.groupSettingUpdate(ctx.jid,'announcement');return {ok:true,message:'🔒 Group locked. Only admins can send messages.'};},{adminOnly:true,botAdmin:true}),
  cmd('groupunlock','Allow all members to send messages','.groupunlock',async ctx=>{await ctx.sock.groupSettingUpdate(ctx.jid,'not_announcement');return {ok:true,message:'🔓 Group unlocked. Members can send messages.'};},{adminOnly:true,botAdmin:true})
];
// Replace the three action entries with real handlers after the shared helpers are defined.
module.exports[0].execute=async(ctx,args)=>moderate(ctx,args,'remove','remove');
module.exports[1].execute=async(ctx,args)=>moderate(ctx,args,'promote','promote');
module.exports[2].execute=async(ctx,args)=>moderate(ctx,args,'demote','demote');
module.exports[0].adminOnly=module.exports[1].adminOnly=module.exports[2].adminOnly=true;
module.exports[0].botAdmin=module.exports[1].botAdmin=module.exports[2].botAdmin=true;
async function moderate(ctx,args,action,label){const who=targetFrom(ctx,args);if(!who)return {ok:false,message:`Mention or reply to the member you want to ${label}.`};const results=await ctx.sock.groupParticipantsUpdate(ctx.jid,[who],action);if(results?.some(r=>String(r.status)!=='200'))return {ok:false,message:'WhatsApp did not apply that change. Check the target and admin permissions.'};return {ok:true,message:`✅ @${who.split('@')[0]} was ${action==='remove'?'removed':action+'d'}.`,mentions:[who]};}

module.exports.push(cmd('delete','Delete the quoted message when permitted','.delete (reply to message)',async ctx=>{
 if(!ctx.quoted?.key?.id)return {ok:false,message:'Reply to the message you want deleted.'};
 await ctx.sock.sendMessage(ctx.jid,{delete:{...ctx.quoted.key,remoteJid:ctx.jid}});
 return {ok:true,message:'🗑️ Delete request submitted.'};
},{adminOnly:true,botAdmin:true}));
